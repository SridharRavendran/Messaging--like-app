document.addEventListener('DOMContentLoaded', function() {
    const createPostForm = document.getElementById('create-post-form');
    const successMessage = document.getElementById('success-message');
  
    createPostForm.addEventListener('submit', function(event) {
      event.preventDefault();
      const title = document.getElementById('title').value;
      const content = document.getElementById('content').value;
  
      // Simulating successful creation
      if (title && content) {
        successMessage.style.display = 'block';
        // Here you would typically send the data to your backend using Ajax
        // and handle the response accordingly
      }
    });
  
    // Simulated previous posts
    const previousPosts = [
      { title: 'First Post', content: 'This is the content of the first post' },
      { title: 'Second Post', content: 'This is the content of the second post' }
    ];
  
    const previousPostsContainer = document.getElementById('previous-posts');
    previousPosts.forEach(post => {
      const postDiv = document.createElement('div');
      postDiv.innerHTML = `<h3>${post.title}</h3><p>${post.content}</p>`;
      previousPostsContainer.appendChild(postDiv);
    });
  });
  